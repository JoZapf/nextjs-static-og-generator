# Dynamic OG Image Generator

> **Build-time Open Graph image generation for Next.js static export projects**

A standalone solution for generating beautiful, branded social media preview images at build time – perfect for static sites that can't use runtime image generation.

![OG Preview](./public/og/og-image.png)

---

## 🎯 Why This Exists

When you share a link on LinkedIn, Twitter, or Facebook, these platforms fetch an **Open Graph (OG) image** to display as a preview. Most solutions require:

- ❌ Server-side rendering (Vercel's `@vercel/og`)
- ❌ Edge functions or serverless infrastructure
- ❌ Runtime image generation

**This project solves the problem for static sites** by generating OG images during the build process, outputting static PNG files that work anywhere.

---

## ✨ Features

- 🖼️ **Build-time generation** – No server required
- 🎨 **Glassmorphism design** – Modern, professional look
- 🔤 **Google Fonts support** – Auto-downloads Montserrat
- 🖼️ **Background image support** – Layer your brand imagery
- 🐳 **Docker-ready** – One command to build
- 📦 **Static export** – Deploy anywhere (Nginx, Apache, S3, etc.)

---

## 🚀 Quick Start

### Using Docker (Recommended)

```bash
# Clone and enter the project
cd dynamic-og

# Start development server (hot-reload)
docker compose up dev

# Or build and preview production output
docker compose up build
docker compose up preview
```

**Access:**
- Development: http://localhost:3000
- Preview: http://localhost:8080

### Without Docker

```bash
# Install dependencies
npm install

# Download Google Fonts
npm run setup

# Generate OG images
npm run generate:og

# Build static site
npm run build

# Preview output
npx serve out -l 8080
```

---

## 📁 Project Structure

```
dynamic-og/
├── app/
│   ├── layout.tsx          # Root layout with OG meta tags
│   ├── page.tsx            # Homepage (renders this README)
│   └── globals.css         # Minimal styling
├── scripts/
│   ├── generate-og-images.ts   # OG image generator
│   └── download-fonts.ts       # Google Fonts downloader
├── assets/
│   ├── bg/                 # Background images
│   │   └── og-background.jpg
│   └── fonts/              # Downloaded fonts (auto-generated)
├── public/
│   └── og/                 # Generated OG images (auto-generated)
├── out/                    # Static export output (auto-generated)
├── docker-compose.yml
├── Dockerfile
└── package.json
```

---

## ⚙️ Configuration

### Customize Content

Edit `scripts/generate-og-images.ts`:

```typescript
const CONTENT = {
  title: 'Your Project Name',
  subtitle: 'Your Tagline Here',
  description: 'A longer description of what your project does.',
  badge: 'yoursite.com',
  filename: 'og-image.png',
};
```

### Customize Design

The template uses a glassmorphism card design. Key style variables:

```typescript
// Background gradient
background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)'

// Card styling
background: 'linear-gradient(145deg, rgba(255,255,255,0.12), rgba(255,255,255,0.05))'
border: '1px solid rgba(255,255,255,0.18)'

// Accent colors (divider line)
background: 'linear-gradient(90deg, #e26b34 0%, #336851 50%, #1b3c65 100%)'
```

### Use Your Own Background Image

1. Place your image in `assets/bg/og-background.jpg`
2. Supported formats: `.jpg`, `.jpeg`, `.png`, `.webp`
3. Recommended size: 1200×630px or larger

---

## 🔧 How It Works

### 1. Font Download (`npm run setup`)

Downloads Montserrat font files from Google Fonts API and saves them locally for offline builds.

### 2. OG Generation (`npm run generate:og`)

Uses **Satori** (Vercel's SVG generator) + **Resvg** (Rust-based PNG renderer):

```
JSX Template → Satori → SVG → Resvg → PNG
```

### 3. Build (`npm run build`)

Next.js static export generates HTML with proper OG meta tags pointing to the generated images.

### 4. Output

```html
<meta property="og:image" content="/og/og-image.png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
```

---

## 🐳 Docker Commands

| Command | Description |
|---------|-------------|
| `docker compose up dev` | Start development server (port 3000) |
| `docker compose up build` | Build static site + generate OG images |
| `docker compose up preview` | Serve built output (port 8080) |
| `docker compose down` | Stop all containers |

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `next` | Static site generator |
| `react` | UI framework |
| `satori` | JSX → SVG conversion |
| `@resvg/resvg-js` | SVG → PNG rendering |
| `gray-matter` | Markdown frontmatter parsing |
| `marked` | Markdown → HTML conversion |

---

## 🎨 Design Inspiration

The glassmorphism card design was inspired by modern UI trends:

- Semi-transparent backgrounds with blur
- Subtle borders and shadows
- Gradient accents
- Clean typography hierarchy

---

## 📄 License

MIT License – Use freely in your own projects.

---

## 🙏 Credits

- **Satori** by Vercel – The engine behind `@vercel/og`
- **Resvg** – High-quality SVG rendering in Rust/WASM
- **Montserrat** – Beautiful open-source font by Julieta Ulanovsky

---

## 🔗 Related

- [Open Graph Protocol](https://ogp.me/)
- [Satori Documentation](https://github.com/vercel/satori)
- [Next.js Static Export](https://nextjs.org/docs/app/building-your-application/deploying/static-exports)

---

*Built with ❤️ as part of the [jozapf.de](https://jozapf.de) portfolio project.*
