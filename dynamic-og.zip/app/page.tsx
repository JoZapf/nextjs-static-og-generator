import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { marked } from 'marked';

export default function Home() {
  // Read README.md content
  const readmePath = join(process.cwd(), 'README.md');
  let readmeContent = '';
  let htmlContent = '';

  if (existsSync(readmePath)) {
    readmeContent = readFileSync(readmePath, 'utf-8');
    htmlContent = marked(readmeContent) as string;
  } else {
    htmlContent = '<p>README.md not found</p>';
  }

  // Check if OG image exists
  const ogImagePath = join(process.cwd(), 'public', 'og', 'og-image.png');
  const ogImageExists = existsSync(ogImagePath);

  return (
    <div className="container">
      {/* Header with OG Image Preview */}
      <header className="header">
        <div className="og-preview">
          {ogImageExists ? (
            <img 
              src="/og/og-image.png" 
              alt="Generated OG Image" 
              className="og-image"
            />
          ) : (
            <div className="og-placeholder">
              <p>🖼️ OG image will appear here after build</p>
              <code>npm run generate:og</code>
            </div>
          )}
        </div>
        <p className="og-caption">
          ↑ This is the generated Open Graph image that appears when sharing on social media
        </p>
      </header>

      {/* README Content */}
      <main className="content">
        <article 
          className="readme"
          dangerouslySetInnerHTML={{ __html: htmlContent }} 
        />
      </main>

      {/* Footer */}
      <footer className="footer">
        <p>
          Generated with <strong>Dynamic OG Generator</strong> • 
          View source on <a href="https://github.com" target="_blank" rel="noopener noreferrer">GitHub</a>
        </p>
      </footer>
    </div>
  );
}
